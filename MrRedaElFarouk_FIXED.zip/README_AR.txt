مشروع Mr Reda El Farouk - نسخة مصححة

تم ضبط Java وKotlin على JVM 17 لحل خطأ:
Inconsistent JVM-target compatibility (Java 1.8 vs Kotlin 17).

طريقة الاستخدام مع إعداد GitHub Actions الموجود:
1) استبدل ملف ZIP القديم في مستودع GitHub بهذا الملف الجديد، مع الاحتفاظ بنفس الاسم:
   MrRedaElFarouk_Tablet_Build.zip
2) بعد Commit، افتح Actions وشغّل Build Mr Reda APK أو انتظر تشغيله تلقائيًا.
3) عند نجاح البناء، افتح العملية ثم نزّل Artifact باسم Mr-Reda-El-Farouk-APK.
4) فك ضغط Artifact وثبّت app-debug.apk.

المشروع يعرض https://mrredaelfarouk.com داخل WebView، ويدعم JavaScript والكوكيز ورفع الملفات.
يتطلب اتصال إنترنت. هذا مشروع مصدر وليس APK جاهزًا.
